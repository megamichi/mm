# Compatibility list for tested device

**THIS IS WORK IN PROGRESS**: If you have tested the library to work with a different device please
send a pull request.

## Android 
| Device | Android OS | Browser | Inline scanning | File Scanning | Known issues |
| --- | --- | --- | --- | --- | --- | 
| One Plus 6T | 10.0 | Chrome 81.0 | ![](./assets/done.png) | <img src="./assets/question.png" width="24px"> | - |

## IOS

| Device | ISO | Browser | Inline scanning | File Scanning | Known issues |
| --- | --- | --- | --- | --- | --- | 
| IPhone 11 | 13.4 | Safari 13.1 | <img src="./assets/cross.png" width="24px"> | <img src="./assets/question.png" width="24px"> | Not working |
| IPhone XS | 13.4 | Safari 13.1 | ![](./assets/done.png) | <img src="./assets/question.png" width="24px"> | - |
