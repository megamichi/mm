/*
 * string.c
 *
 * Some of string manipulation functions. Look at the
 * header file. All are defined as inline.
 */
#include <string.h>
