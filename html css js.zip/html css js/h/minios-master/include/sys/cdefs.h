#ifndef _SYS_CDEFS_H
#define _SYS_CDEFS_H 1

#define __MINIOS_LIBC 1

#endif
