#ifndef _SCHED_H
#define _SCHED_H

extern void timer_intr(void);
extern void sched_init(void);

#endif
