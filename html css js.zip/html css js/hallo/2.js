var
  deziRegex = new RegExp('[^0-9]'),
  dualRegex = new RegExp('[^0-1]'),
  hexaRegex = new RegExp('[^0-9a-fA-F]')
  dezi= document.getElementById('dezimal'),
  dual= document.getElementById('dual'),
  hexa= document.getElementById('hexadezimal');


function deziInput(){
  if (deziRegex.test(dezi.value) == false){
    dual.value = Number(dezi.value).toString(2);
    hexa.value = Number(dezi.value).toString(16);
  }else{
    alert('Please enter a valid number');
  }
}

function hexaInput(){
  if (hexaRegex.test(hexa.value) == false){
    dezi.value = parseInt(hexa.value, 16);
    dual.value = Number(dezi.value).toString(2);
  }else{
    alert('Please enter a valid number');
  }
}

function dualInput(){
  if (dualRegex.test(dual.value) == false){
    dezi.value = parseInt(dual.value, 2);
    hexa.value = Number(dezi.value).toString(16);
    console.log('pups');
  }else{
    alert('Please enter a valid number');
  }
}