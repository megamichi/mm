
function los() {
    document.getElementById(
        "ausgabe"
    ).innerHTML = "<h1>hallo</h1>"
}