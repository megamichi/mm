
var m =0;

function los() {
    m = m +1;
    document.getElementById(
        "ausgabe"
    ).innerHTML = m
}